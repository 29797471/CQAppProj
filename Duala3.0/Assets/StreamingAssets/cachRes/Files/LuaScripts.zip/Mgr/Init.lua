require 'Mgr/TriggerMgr'

require 'Mgr/PrefabMgr'

require 'Mgr/TextMgr'

require 'Mgr/CommonWinMgr'

require "Mgr/SaveDataMgr"

require "Mgr/RoadMgr"

require "Mgr/Trade/Init"