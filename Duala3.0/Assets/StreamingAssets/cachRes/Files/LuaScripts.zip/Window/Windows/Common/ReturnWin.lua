super_class.ReturnWin(LuaWin)

function ReturnWin:OnInit()
	
end
