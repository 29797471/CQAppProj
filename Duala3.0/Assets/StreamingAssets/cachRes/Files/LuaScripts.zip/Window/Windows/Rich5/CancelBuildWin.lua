super_class.CancelBuildWin(LuaWin)

function CancelBuildWin:OnInit()
	
end

function CancelBuildWin:OnData()
	
end
