--等待获取数据
function StartupWin:WaitGetData(OnGetData)
	OnGetData()
end

--窗口资源加载完成时
function StartupWin:OnInit()
	
end

--窗口显示时
function StartupWin:OnShow()
	
end

--窗口关闭时
function StartupWin:OnHide()
	 
end
