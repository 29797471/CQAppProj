super_class.MenuWin(LuaWin)

function MenuWin:OnInit()
	self.data=
	{
		showCenter=true,
		selectCenter=false,
		showChoose=true,
		selectChoose=false,
		btns={design=false},
	}

end

function MenuWin:OnShow()
end
