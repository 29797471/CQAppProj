super_class.SettingWin(LuaWin)

function SettingWin:OnInit()
	self.dlg.DataContent=
	{
		Ranking=function ()
			
		end,
	}
end

function SettingWin:OnData()
	
end
