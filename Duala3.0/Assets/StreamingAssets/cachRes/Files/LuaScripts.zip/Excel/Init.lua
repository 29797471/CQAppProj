
require "Excel/More/Config_GlobalConst"
require "Excel/More/Config_AppConfig"
require "Excel/More/Config_Win"
require "Excel/More/Config_WinLayer"
require "Excel/More/Config_CommonWin"
require "Excel/More/Config_CommonWinStyle"
require "Excel/More/Config_PrintColor"